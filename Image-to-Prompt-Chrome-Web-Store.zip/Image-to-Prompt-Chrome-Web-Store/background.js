
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === chrome.runtime.OnInstalledReason.INSTALL) {
    const installDate = new Date().toISOString();
    
    chrome.storage.sync.set({ installDate }, () => {
      console.log('InstallDate:', installDate);
    });
    await chrome.storage.local.set({ responseCount: 0 });
    await setupDefaultSettings();
  }
});

chrome.action.onClicked.addListener(async (tab) => {
  if (tab.id) {
    try {
      await checkAndInjectContentScript(tab.id);

      chrome.tabs.sendMessage(
        tab.id,
        { action: "isInterfaceImageToPromptReady" },
        (response) => {
          if (
            chrome.runtime.lastError ||
            !response ||
            !response.isInterfaceImageToPromptReady
          ) {
            chrome.tabs.sendMessage(tab.id, { action: "openWindow" });
          }
        }
      );

    } catch (error) {
      console.error(`Error embedding script: ${error}`);
    }
  }
  // const currentCount = await getResponseCounter();
  // console.log('currentCount', currentCount);

  // if (currentCount >= 1) {
  //   chrome.tabs.sendMessage(tab.id, {
  //     action: "triggerPaywall",
  //   });
  //  // return;
  // }
});

async function checkAndInjectContentScript(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { action: "ping" });
    return true;
  } catch (error) {
    await chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ["content.js"],
    });
    return false;
  }
}

//-------------------------------------------------

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === "upload_image" && request.imageBase64) {
    sendDataToServer(sender.tab.id, request.imageBase64, null);
  }
  if (request.action === "upload_image_url" && request.imageUrl) {
    processImage(sender.tab.id, request.imageUrl);
  }
  return true;
});

//-------------------contextMenus---------------
chrome.contextMenus.remove("imageAsBase64ToPrompt", () => {
  if (chrome.runtime.lastError) {
    console.log("Select the image by clicking in the context menu.");
  }

  chrome.contextMenus.create({
    id: "imageAsBase64ToPrompt",
    title: "Image to Prompt",
    contexts: ["image"],
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "imageAsBase64ToPrompt" && info.srcUrl) {
    const isInterfaceImageToPromptReady = await new Promise((resolve) => {
      chrome.tabs.sendMessage(
        tab.id,
        { action: "isInterfaceImageToPromptReady" },
        (response) => {
          if (chrome.runtime.lastError || !response) {
            resolve(false);
          } else {
            resolve(response.isInterfaceImageToPromptReady);
          }
        }
      );
    });

    if (!isInterfaceImageToPromptReady) {
      await new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(
          tab.id,
          { action: "openWindow" },
          (response) => {
            if (
              !chrome.runtime.lastError &&
              response &&
              response.isInterfaceImageToPromptReady
            ) {
              resolve(0);
            } else {
              reject(
                chrome.runtime.lastError || new Error("Failed to open window")
              );
            }
          }
        );
      });
    }

    await processImage(tab.id, info.srcUrl);
  }
});

async function processImage(tabId, srcUrl) {
  try {

    const imageBase64 = await fetchImageFromBackground(srcUrl);

    openResultsWindow(tabId, "display_preview", imageBase64);

    await sendDataToServer(tabId, imageBase64, null);

  } catch (error) {
    console.error("Ошибка в processImage:", error);

    await sendDataToServer(tabId, null, srcUrl);
  }
}

async function fetchImageFromBackground(srcUrl) {
  const response = await fetch(srcUrl);
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  const blob = await response.blob();
  return new Promise((resolve, reject) => {
    let reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("FileReader error"));
    reader.readAsDataURL(blob);
  });
}

async function resetResponseCounter() {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set({ responseCount: 0 }, () => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(0);
      }
    });
  });
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}




async function sendDataToServer(tabId, imageBase64 = null, srcUrl = null) {
  try {
    //await resetResponseCounter()
    const settings = await getSettings();
    const userPreferredLanguage = settings.userPreferredLanguage;
    const extensionUserId = settings.extensionUserId;

    const formData = new FormData();
    if (imageBase64) {
      const imageBlob = dataURItoBlob(imageBase64);
      formData.append("image", imageBlob, "image.png");
    } else if (srcUrl) {
      formData.append("image_url", srcUrl);
    } else {
      throw new Error("It is necessary to specify either imageBase64 or srcUrl.");
    }
    formData.append("user", extensionUserId);
    formData.append("lang", userPreferredLanguage);

    const response = await fetch("http://158.160.66.115:40000/image_to_prompt", {
      method: "POST",
      body: formData,
    });

    if (!response.ok) {
      let errorData;
      try {
        errorData = await response.json();
        if (errorData && errorData.error && errorData.error.message) {
          throw new Error(errorData.error.message);
        } else {
          throw new Error("Unknown server error");
        }
      } catch (e) {
        if (response.status === 500) {
          throw new Error("Internal Server Error");
        } else {
          throw new Error("Server responded with an error");
        }
      }
    }

    const data = await response.json();

    if (data.type === "error") {
      throw new Error(data.error.message);
    }


    chrome.tabs.sendMessage(tabId, {
      action: "serverResponse",
      data: data.prompt,
    });
  } catch (error) {
    console.error("Error:", error);

    if (error.message === "Unsupported image format." && srcUrl) {
      await sendDataToServer(tabId, null, srcUrl);
    } else if (error.message === "Internal Server Error") {
      chrome.tabs.sendMessage(tabId, {
        action: "serverResponse",
        error: "The server is currently unavailable. Please try again later.",
      });
    } else if (error.message === "Server responded with an error") {
      chrome.tabs.sendMessage(tabId, {
        action: "serverResponse",
        error: "Server error. Please try again later.",
      });
    } else {
      chrome.tabs.sendMessage(tabId, {
        action: "serverResponse",
        error: "Failed to extract the image. Try to download it and upload from your device.",
      });
    }
  }
}

function openResultsWindow(tabId, action, imageBase64) {
  chrome.tabs.sendMessage(
    tabId,
    {
      action: action,
      imageBase64: imageBase64,
    },
    function (response) {
      if (chrome.runtime.lastError) {
        console.error(tabId + ":", chrome.runtime.lastError.message);
      }
    }
  );
}

// Вспомогательная функция для конвертации Data URI в Blob
function dataURItoBlob(dataURI) {
  const byteString = atob(dataURI.split(",")[1]);
  const mimeString = dataURI.split(",")[0].split(":")[1].split(";")[0];
  const buffer = new ArrayBuffer(byteString.length);
  const intArray = new Uint8Array(buffer);

  for (let i = 0; i < byteString.length; i++) {
    intArray[i] = byteString.charCodeAt(i);
  }

  return new Blob([buffer], { type: mimeString });
}
// -------------------userId------------------------
async function generateExtensionUserId() {
  return new Promise((resolve, reject) => {
    let extensionUserId = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
      /[xy]/g,
      function (c) {
        var r = (Math.random() * 16) | 0,
          v = c == "x" ? r : (r & 0x3) | 0x8;
        return v.toString(16);
      }
    );
    resolve(extensionUserId);
  });
}

async function getSettings() {
  const keysToGet = ["extensionUserId", "userPreferredLanguage"];
  let result = {};
  try {
    result = await new Promise((resolve, reject) => {
      chrome.storage.local.get(keysToGet, function (result) {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(result);
        }
      });
    });

    if (!result.extensionUserId) {
      result.extensionUserId = await generateExtensionUserId();
      await saveToStorage("extensionUserId", result.extensionUserId);
    }
  } catch (error) {
    if (!result.extensionUserId) {
      result.extensionUserId = await generateExtensionUserId();
      await saveToStorage("extensionUserId", result.extensionUserId);
    }
  }

  return {
    extensionUserId: result.extensionUserId,
    userPreferredLanguage: result.userPreferredLanguage || "en-US",
  };
}

async function setupDefaultSettings() {
  await saveDefaultIfNotExists("userPreferredLanguage", "en-US");
  await saveDefaultIfNotExists(
    "extensionUserId",
    await generateExtensionUserId()
  );
}

async function saveDefaultIfNotExists(settingKey, defaultValue) {
  const result = await getSettings(settingKey);
  if (!result) {
    await saveToStorage(settingKey, defaultValue);
  }
}

async function saveToStorage(key, value) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set({ [key]: value }, function () {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve();
      }
    });
  });
}
//--------------------------------------------------------
async function incrementResponseCounter() {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(["responseCount"], (result) => {
      const currentCount = result.responseCount || 0;
      const newCount = currentCount;

      chrome.storage.local.set({ responseCount: newCount }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(newCount);
        }
      });
    });
  });
}

async function getResponseCounter() {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(["responseCount"], (result) => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(result.responseCount || 0);
      }
    });
  });
}


//-----------------------notifications--------------------
// function showNotification() {
//   chrome.notifications.create({
//     type: "basic",
//     iconUrl: "icons/your-icon.png",
//     title: "Data Processed",
//     message: "Click to view the result.",
//     buttons: [{ title: "Show" }],
//     priority: 2,
//   });
// }

// chrome.notifications.onButtonClicked.addListener(function (
//   notificationId,
//   buttonIndex
// ) {
//   if (buttonIndex === 0) {
//     // Open popup.html
//     chrome.tabs.create({ url: "popup.html" });
//   }
// });
// showNotification();
