let isInterfaceImageToPromptReady = false;
//-------------------------------------------------------
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === "ping") {
    sendResponse({ status: "ok" });
  }
  if (request.action === "openWindow") {
    if (!isInterfaceImageToPromptReady) {
      createAndShowWindow();
      sendResponse({ isInterfaceImageToPromptReady: true });
    } else {
      sendResponse({ isInterfaceImageToPromptReady: true });
    }
  }
  if (request.action === "isInterfaceImageToPromptReady") {
    sendResponse({
      isInterfaceImageToPromptReady: isInterfaceImageToPromptReady,
    });
  }

  if (request.action === "display_preview" && request.imageBase64) {
    const shadowHost = document.querySelector("#shadowHostITPrompt");
    const shadowRoot = shadowHost.shadowRoot;
    const dropZone = shadowRoot.querySelector("#shadowDropZoneITPrompt");
    const result = shadowRoot.querySelector("#shadowResult");
    const uploadInfo = shadowRoot.querySelector("#shadowUploadInfo");
    const preloader = shadowRoot.querySelector("#shadowPreloader");
    const previewImg = shadowRoot.querySelector("#shadowPreviewImg");
    if (shadowHost && shadowHost.shadowRoot) {
      dropZone.style.display = "flex";
      uploadInfo.style.display = "none";
      result.style.display = "none";
      previewImg.style.display = "block";
      preloader.style.display = "block";
      previewImg.style.display = "block";
      previewImg.src = request.imageBase64;
      sendResponse({ success: true });
    } else {
      console.error("content:no shadowHost / shadowHost.shadowRoot");
    }
  }

  if (request.action === "closeWindow") {}

  if (
    request.action === "serverResponse" ||
    request.action === "invalidLinkFormat"
  ) {
    const shadowHost = document.querySelector("#shadowHostITPrompt");
    const shadowRoot = shadowHost.shadowRoot;
    const dropZone = shadowRoot.querySelector("#shadowDropZoneITPrompt");
    const result = shadowRoot.querySelector("#shadowResult");
    const resultText = shadowRoot.querySelector("#shadowResult-text");
    const backToMainBtn = shadowRoot.querySelector("#shadowBackToMainBtn");
    const previewImg = shadowRoot.querySelector("#shadowPreviewImg");
    const preloader = shadowRoot.querySelector("#shadowPreloader");
    const languageSelectWrapper = shadowRoot.querySelector(
      "#languageSelectWrapper"
    );
    previewImg.style.display = "none";
    preloader.style.display = "none";
    dropZone.style.display = "none";
    languageSelectWrapper.style.display = "none";
    result.style.display = "block";

    if (request.error) {
      resultText.textContent = request.error;
    } else if (request.data) {
      resultText.textContent = request.data;
    } else {
      resultText.textContent = "Received an empty response from the server.";
    }

    backToMainBtn.disabled = false;
    return;
  }
});

window.addEventListener("message", (event) => {
  if (event.source !== window || !event.data) {
    return;
  }

  if (event.data.type === "PAYWALL_OPEN_SUCCESS") {
    console.log("The free inquiries are over.");
  } else if (event.data.type === "PAYWALL_OPEN_ERROR") {
    console.error("Error:", event.data.error);
  }
});




async function openPaywall() {
  try {
    await paywall.open({ resolveEvent: "success-purchase" });
  } catch (error) {
    console.error("Error:", error);

    if (error.visibility_status_reason === "openings-trial") {
      console.error("The free inquiries aren't over yet.");
    }
  }
}

function createAndShowWindow() {
  const shadowHost = document.createElement("div");
  document.body.appendChild(shadowHost);
  shadowHost.id = "shadowHostITPrompt";
  const shadowRoot = shadowHost.attachShadow({ mode: "open" });
   const script = document.createElement("script");
   script.type = "module";
   document.documentElement.appendChild(script);
  const shadowContent = document.createElement("div");
  shadowContent.id = "pageContainer";
  shadowContent.innerHTML = `
  <header class="header" id="shadowHeader">
        <div class="title">Image to Prompt</div>
      </header>
      <main class="main center-col" >
     
        <div id="shadowDropZoneITPrompt" class=" center-col drop-zone">
          <div id="shadowPreloader" class="shadow-preloader" style="display: none;"></div>
          <div id="shadowUploadInfo" class="upload__info center-col">
          <button id="shadowUploadBtn" class="upload-btn center-col">
          <span class="upload-btn__content--icon-left">
              <svg class="upload__icon" width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9.51833 2.46809L14.014 6.84059C14.3194 7.1269 14.3298 7.59942 14.0371 7.89809C13.8923 8.04008 13.6952 8.11994 13.4896 8.11994C13.284 8.11994 13.0869 8.04008 12.9421 7.89809L9.74195 4.80809V12.7806C9.74195 13.1948 9.39671 13.5306 8.97083 13.5306C8.54495 13.5306 8.19971 13.1948 8.19971 12.7806V4.80809L5.0227 7.89809C4.71675 8.15293 4.26069 8.13579 3.97586 7.85877C3.69103 7.58174 3.67342 7.13816 3.93542 6.84059L8.43105 2.46809C8.73181 2.1773 9.21756 2.1773 9.51833 2.46809Z" fill="#FDF2F8"/>
                  <path d="M5.11523 14.2806H12.8264C13.2523 14.2806 13.5975 14.6164 13.5975 15.0306C13.5975 15.4448 13.2523 15.7806 12.8264 15.7806H5.11523C4.68936 15.7806 4.34411 15.4448 4.34411 15.0306C4.34411 14.6164 4.68936 14.2806 5.11523 14.2806Z" fill="#FDF2F8"/>
              </svg>
              Upload Image
          </span>
          </button>
          <div id="shadowUploadText" class="upload__text">
          Or drop your image file here or right click on the<br>image
          </div>
          </div>
          <input type="file" id="shadowFileInputITPrompt" accept="image/*"style="display: none;" />
          <img id="shadowPreviewImg" class="preview__img" style="display: none;">
        </div>
        <div id="languageSelectWrapper" class="language-select__wrapper">
        <span class="language-select__text">Prompt language</span>
          <select id="language-select" class="language-select">
            <option value="ar">Arabic</option>
            <option value="am">Amharic</option>
            <option value="bg">Bulgarian</option>
            <option value="bn">Bengali</option>
            <option value="ca">Catalan</option>
            <option value="cs">Czech</option>
            <option value="da">Danish</option>
            <option value="de">German</option>
            <option value="el">Greek</option>
            <option value="en">English</option>
            <option value="en-AU">English (Australia)</option>
            <option value="en-GB">English (Great Britain)</option>
            <option value="en-US" selected>English (USA)</option>
            <option value="es">Spanish</option>
            <option value="es-419">Spanish (Latin America and Caribbean)</option>
            <option value="et">Estonian</option>
            <option value="fa">Persian</option>
            <option value="fi">Finnish</option>
            <option value="fil">Filipino</option>
            <option value="fr">French</option>
            <option value="gu">Gujarati</option>
            <option value="he">Hebrew</option>
            <option value="hi">Hindi</option>
            <option value="hr">Croatian</option>
            <option value="hu">Hungarian</option>
            <option value="id">Indonesian</option>
            <option value="it">Italian</option>
            <option value="ja">Japanese</option>
            <option value="kn">Kannada</option>
            <option value="ko">Korean</option>
            <option value="lt">Lithuanian</option>
            <option value="lv">Latvian</option>
            <option value="ml">Malayalam</option>
            <option value="mr">Marathi</option>
            <option value="ms">Malay</option>
            <option value="nl">Dutch</option>
            <option value="no">Norwegian</option>
            <option value="pl">Polish</option>
            <option value="pt-BR">Portuguese (Brazil)</option>
            <option value="pt-PT">Portuguese (Portugal)</option>
            <option value="ro">Romanian</option>
            <option value="ru">Russian</option>
            <option value="sk">Slovak</option>
            <option value="sl">Slovenian</option>
            <option value="sr">Serbian</option>
            <option value="sv">Swedish</option>
            <option value="sw">Swahili</option>
            <option value="ta">Tamil</option>
            <option value="te">Telugu</option>
            <option value="th">Thai</option>
            <option value="tr">Turkish</option>
            <option value="uk">Ukrainian</option>
            <option value="vi">Vietnamese</option>  
            <option value="zh-CN">Chinese (China)</option>
            <option value="zh-TW">Chinese (Taiwan)</option>
          </select>
        </div>
        <div id="shadowResult" class="shadow-result" style="display: none;">
          <div id="shadowResult-text" class="result-text"></div>
          <div id="shadowResultButtons" class="result__buttons">
              <button class="back-to-main__btn" id = "shadowBackToMainBtn">Back to main</button>
              <button class="copy-result__btn" id = "shadowCopyResultBtn">Copy</button>
          </div>
        </div>
      </main>`;
  const robotoRegularWoff2 = chrome.runtime.getURL(
    "fonts/Roboto-Regular.woff2"
  );
  const robotoRegularWoff = chrome.runtime.getURL("fonts/Roboto-Regular.woff");
  const robotoBoldWoff2 = chrome.runtime.getURL("fonts/Roboto-Regular.woff2");
  const robotoBoldWoff = chrome.runtime.getURL("fonts/Roboto-Regular.woff");
  const robotoMediumWoff2 = chrome.runtime.getURL("fonts/Roboto-Regular.woff2");
  const robotoMediumWoff = chrome.runtime.getURL("fonts/Roboto-Regular.woff");
  const shadowStyles = document.createElement("style");
  shadowStyles.textContent = `
      #paywallContainer {
      position: absolute;
      background-color: #fff;
      border: 1px solid #ccc;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      overflow: hidden;
      top:20px;
      z-index: 1000;
    }
  #shadowContainerITPrompt {
    position: fixed;
    bottom: 0;
    right: 10px;
    background-color: white;
    border-radius: 24px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    z-index: 10000;
  }
  #shadowClose-buttonITPrompt {
    position: absolute;
    top: 22px;
    right: 30px;
    cursor: pointer;
  }

  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 400;
    src: local("Roboto"), url("${robotoRegularWoff2}") format("woff2"),
      url("${robotoRegularWoff}") format("woff");
  }
  
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 500;
    src: local("Roboto Medium"), url("${robotoMediumWoff2}") format("woff2"),
    url("${robotoMediumWoff}") format("woff");
  }
  
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 700;
    src: local("Roboto Bold"), url("${robotoBoldWoff2}") format("woff2"),
      url("${robotoBoldWoff}") format("woff");
  }
  * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }
  
  :root {
    --default-main: #ED479E;
    --hover-main: #DC267C;
    --active-main: #BF1762;
    --disabled-main: #FCE7F4;
    --text: #FDF2F8;
    --gray-400: #322F35;
    --black: #1c1c1e;
    --white: #FFFFFF;
  }
  .hidden {
    display: none;
  }

  .center-row {
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .center-col {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }
  .header {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 368px;
    height: 64px;
    border-top-left-radius: 24px;
    border-top-right-radius: 24px;
    background-color: #ED479E; 
  }
  .title {
    color: #FDF2F8;
    text-align: center;
    font-family: "Roboto", sans-serif;
    font-size: 22px;
    font-style: normal;
    font-weight: 400;
    line-height: 28px;
  }
  .main {
    position: relative;
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 24px;
  }
  
  .drop-zone {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 12px;
    text-align: center;
    width: 320px;
    height: 180px;
    background-color: #FCE7F4;
    border-radius: 24px;
    border: 2px dashed black;
    cursor: pointer;
  }
  .highlight{
    border: none;
   background-color: #f7eaff;
    transition: background-color 0.3s ease, border-color 0.3s ease;
  }
  #shadowDropZoneITPrompt img {
    max-width: 100%;
    max-height: 100%;
    object-fit: contain;
  }
  
  #shadowDrop-zone.dragover {
    border-color: #000; /* Выделение области при перетаскивании */
  }
  #shadowFileInputITPrompt {
    opacity: 0;
    position: absolute;
    top: 0;
    left: 0;
    cursor: pointer;
  }
  .upload__info{
    position: absolute;
    top: 60%;
    left: 50%;
    transform: translate(-50%, -50%);
  }

  .upload-btn__content--icon-left{
    display: flex;
    justify-content: center;
    align-items: center;
    border: none;
    background-color: transparent;
    color: #FDF2F8;
    text-align: center;
    font-family: "Roboto", sans-serif;
    font-size: 14px;
    font-style: normal;
    font-weight: 500;
    line-height: 20px;
    letter-spacing: 0.1px;
    cursor: pointer;
  }

  .upload__icon{
    margin-right: 7px;
  }
  .upload-btn {
    width: 153px;
    height: 40px;
    margin: 12px;
    border-radius: 24px;
    border: none;
    background-color: #ED479E;
    cursor: pointer;
    transition: box-shadow 0.2s, transform 0.2s;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
  }
  .upload-btn:hover{
    background-color: #DC267C;
  }

.upload-btn:active, .copy-result__btn:active {
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2); /* Более "мягкая" тень */
  background-color: #BF1762;
  transform: translateY(2px); /* Небольшое смещение вниз */
}

.upload__text{
  width: 274px;
  height: 34px;
  text-align: center;
  font-family: "Roboto", sans-serif;
  font-size: 12px;
  font-style: normal;
  font-weight: 400;
  line-height: 20px;
  letter-spacing: 0.03px;
  color: #322F35;
}

 .language-select__wrapper {
   display: flex;
   align-items: center;
   gap: 20px;
 }

.language-select__text{
  text-align: center;
font-family: "Roboto", sans-serif;
font-size: 12px;
font-style: normal;
font-weight: 400;
line-height: 20px;
letter-spacing: 0.03px;
color: #322F35;
}
#language-select {
  width: 112px;
  height: 28px;
  padding-left: 17px;
  padding-right: 7px;
  border-radius: 24px;
  border: 2px solid #ED479E;
  background-color: #FFFFFF;
  color: #ED479E;
  font-family: "Poppins", sans-serif;
  font-size: 14px;
  font-style: normal;
  font-weight: 500;
  line-height: normal;
  cursor: pointer;
  text-overflow: ellipsis;
  overflow: hidden;
  outline: none;
}

#language-select:focus{
  outline: none;
}
  .shadow-result{
    position:relative;
    width: 320px;
    min-height: 100px;
    background-color: transparent ;
    border-radius: 12px;
  }
  #shadowPreloader {
    position:absolute;
    top: 30%;
    left: 37%;
    transform: translate(-50%, -50%);
    height: 80px;
    width: 80px;
    margin: auto;
    border: 3px solid #FCE7F4;
    border-top: 3px solid #ED479E;
    border-radius: 50%;
    animation: rotate 1s infinite linear;
  }
  .result-text{
    min-height: 100px;
    max-height: 300px;
    overflow-y: auto;
    margin-bottom: 12px;
    padding: 12px;
    background-color: #322F35;
    border-radius: 12px;
    color: #fff;
    font-family: "Roboto", sans-serif;
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    line-height: 20px;
    scrollbar-width: thin; /* Уменьшенная ширина полосы прокрутки для Firefox*/
    scrollbar-color: #625C66 #48454D; /* Цвета ручки и дорожки прокрутки для Firefox*/
}
.result-text::-webkit-scrollbar {
  width: 8px; /* Ширина полосы прокрутки */
}

.result-text::-webkit-scrollbar-track {
  background: #48454D; /* Цвет дорожки прокрутки */
  border-radius: 10px; /* Закругленные углы дорожки прокрутки */
}

.result-text::-webkit-scrollbar-thumb {
  background: #625C66; /* Цвет ручки прокрутки */
  border-radius: 10px; /* Закругленные углы ручки прокрутки */
}

.result-text::-webkit-scrollbar-thumb:hover {
  background: #78757D; /* Цвет ручки прокрутки при наведении */
}
.result__buttons{
    display: flex;
    justify-content: space-between;
}
.copy-result__btn:active,.back-to-main__btn:active {
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2); /* Более "мягкая" тень */
    transform: translateY(2px); /* Небольшое смещение вниз */
}
.copy-result__btn:hover {
    background-color: #DC267C;
    outline: none;
}
.back-to-main__btn:hover {
    background-color: #FCE7F4;
    outline: none;
}
.copy-result__btn{
    width: 80px;
    height: 35px;
    border-radius: 24px;
    border: none;
    background-color: #ED479E;
    /* #48464C */
    color: #FDF2F8;
    text-align: center;
    font-family: "Roboto", sans-serif;
    font-size: 16px;
    font-style: normal;
    font-weight: 500;
    line-height: 19px; 
    letter-spacing: 0.1px; 
    cursor: pointer;
    transition: box-shadow 0.2s, transform 0.2s;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2); 
}
.back-to-main__btn{
    width: 140px;
    height: 35px;
    border-radius: 24px;
    border: 1px solid #ED479E;
    background-color:#FFF;
    color: #ED479E;
    text-align: center;
    font-family: "Roboto", sans-serif;
    font-size: 16px;
    font-style: normal;
    font-weight: 500;
    line-height: 19px; 
    letter-spacing: 0.1px;  
    cursor: pointer;
    transition: box-shadow 0.2s, transform 0.2s;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2); 
}
.back-to-main__btn.disabled {
  background-color: #ddd;
  color: #aaa;
  cursor: not-allowed;
  box-shadow: none; /* Отсутствие тени для более "плоского" вида */
}

.done {
  animation: changeColor 0.3s forwards;
}

@keyframes changeColor {
  from {
    background-color: #ED479E; /* Начальный цвет */
  }
  to {
    background-color: #50A45D; /* Конечный цвет */
  }
}

@keyframes rotate {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
`;

  const shadowContainer = document.createElement("div");
  shadowContainer.id = "shadowContainerITPrompt";
  const closeButton = document.createElement("button");
  closeButton.id = "shadowClose-buttonITPrompt";
  const imageAsDataURI =
    "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHZpZXdCb3g9IjAgMCAxOCAxOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGcgaWQ9IkNsb3NlIj4KPHBhdGggaWQ9Ikljb24iIGQ9Ik0xNC43ODkxIDEzLjc5M0w5Ljk5Mzc2IDkuMDAwMjdMMTQuNzg5MSA0LjI0Mjg1QzE1LjAyOTQgMy45NjQ1MiAxNS4wMTY0IDMuNTQ2ODMgMTQuNzU5MiAzLjI4NDIxQzE0LjUwMjEgMy4wMjE1OCAxNC4wODc0IDMuMDAyNTYgMTMuODA3NiAzLjI0MDU1TDguOTk4MjQgNy45NjI2OEw0LjI3MzAxIDMuMjA1MjZDMy45OTk1NiAyLjkzMTU4IDMuNTU3OTQgMi45MzE1OCAzLjI4NDQ5IDMuMjA1MjZDMy4xNTE3NyAzLjMzNzc5IDMuMDc3MTIgMy41MTgyIDMuMDc3MTIgMy43MDY0MUMzLjA3NzEyIDMuODk0NjEgMy4xNTE3NyA0LjA3NTAzIDMuMjg0NDkgNC4yMDc1Nkw4LjAwMjcxIDguOTU3OTJMMy4yMDczOCAxMy43MDgzQzMuMDc0NjUgMTMuODQwOCAzIDE0LjAyMTIgMyAxNC4yMDk0QzMgMTQuMzk3NiAzLjA3NDY1IDE0LjU3ODEgMy4yMDczOCAxNC43MTA2QzMuMzM5NjggMTQuODQyNyAzLjUxODc5IDE0LjkxNjQgMy43MDUxNCAxNC45MTUzQzMuODg4MDcgMTQuOTE2NCA0LjA2NDE4IDE0Ljg0NTUgNC4xOTU4OSAxNC43MTc2TDguOTk4MjQgOS45NTMxN0wxMy44MDc2IDE0Ljc5NTNDMTMuOTM5OSAxNC45Mjc0IDE0LjExOSAxNS4wMDExIDE0LjMwNTQgMTVDMTQuNDg5MyAxNC45OTkyIDE0LjY2NTUgMTQuOTI1NyAxNC43OTYxIDE0Ljc5NTNDMTQuOTI3OSAxNC42NjE4IDE1LjAwMTMgMTQuNDgwOSAxNSAxNC4yOTI3QzE0Ljk5ODcgMTQuMTA0NSAxNC45MjI3IDEzLjkyNDYgMTQuNzg5MSAxMy43OTNaIiBmaWxsPSIjRkRGMkY4Ii8+CjwvZz4KPC9zdmc+Cg==";
  closeButton.style.backgroundImage = `url('${imageAsDataURI}')`;
  closeButton.style.backgroundColor = "transparent";
  closeButton.style.backgroundRepeat = "no-repeat";
  closeButton.style.backgroundPosition = "center center";
  closeButton.style.width = "24px";
  closeButton.style.height = "24px";
  closeButton.textContent = "";
  closeButton.style.border = "none";
  closeButton.onclick = () => {
    isInterfaceImageToPromptReady = false;
    shadowHost.remove();
  };

  shadowRoot.appendChild(shadowStyles);
  shadowContainer.appendChild(closeButton);
  shadowContainer.appendChild(shadowContent);
  shadowRoot.appendChild(shadowContainer);

  const uploadInfo = shadowRoot.querySelector("#shadowUploadInfo");
  const uploadBtn = shadowRoot.querySelector("#shadowUploadBtn");
  const dropZone = shadowRoot.querySelector("#shadowDropZoneITPrompt");
  const fileInput = shadowRoot.querySelector("#shadowFileInputITPrompt");
  const copyResultBtn = shadowRoot.querySelector("#shadowCopyResultBtn");
  const backToMainBtn = shadowRoot.querySelector("#shadowBackToMainBtn");
  const previewImg = shadowRoot.querySelector("#shadowPreviewImg");
  const result = shadowRoot.querySelector("#shadowResult");
  const resultText = shadowRoot.querySelector("#shadowResult-text");
  const preloader = shadowRoot.querySelector("#shadowPreloader");
  const languageSelectWrapper = shadowRoot.querySelector(
    "#languageSelectWrapper"
  );
  const selectElement = shadowRoot.querySelector("#language-select");

  copyResultBtn.addEventListener("click", copyToClipboard);
  backToMainBtn.addEventListener("click", resetTheInterface);
  //----------------------------------------------
  chrome.storage.local.get("userPreferredLanguage", function (data) {
    if (data.userPreferredLanguage) {
      selectElement.value = data.userPreferredLanguage;
    }

    selectElement.addEventListener("change", function () {
      const selectedLanguage = selectElement.value;
      chrome.storage.local.set({ userPreferredLanguage: selectedLanguage });
      chrome.runtime.sendMessage({
        action: "change_language_preference",
        userPreferredLanguage: selectedLanguage,
      });
    });
  });
 
  //--------------------------------
  uploadBtn.addEventListener("click", function () {
    fileInput.click();
  });

  fileInput.addEventListener("change", function () {
    if (fileInput.files.length > 0) {
      let file = fileInput.files[0];
      processFile(file);
      fileInput.value = "";
    }
  });

  ["dragenter", "dragover", "dragleave", "drop"].forEach((eventName) => {
    dropZone.addEventListener(eventName, preventDefaults, false);
  });

  function preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
  }

  ["dragenter", "dragover"].forEach((eventName) => {
    dropZone.addEventListener(eventName, highlight, false);
  });

  ["dragleave", "drop"].forEach((eventName) => {
    dropZone.addEventListener(eventName, unHighlight, false);
  });

  function highlight(e) {
    dropZone.classList.add("highlight");
  }

  function unHighlight(e) {
    dropZone.classList.remove("highlight");
  }

  dropZone.addEventListener("drop", handleDrop, false);

  function handleDrop(e) {
    preventDefaults(e);
    unHighlight(e);
    let dt = e.dataTransfer;
    if (!dt.files || dt.files.length === 0) {
      let items = dt.items;
      if (items) {
        for (let i = 0; i < items.length; i++) {
          if (
            items[i].kind === "string" &&
            (items[i].type.match("^text/plain") ||
              items[i].type.match("^text/uri-list"))
          ) {
            items[i].getAsString((text) => {
              if (isImageUrl(text)) {
                changeViewToDisplayPreview();
                preloader.style.display = "block";
                previewImg.src = text;

                if (text.startsWith("data:image")) {
                  // Обрабатываем Data URL: извлекаем base64
                  const base64Data = text.split("base64,")[1];
                  chrome.runtime.sendMessage({
                    action: "upload_image",
                    imageBase64: base64Data,
                  });
                } else {
                  chrome.runtime.sendMessage({
                    action: "upload_image_url",
                    imageUrl: text,
                  });
                }

                previewImg.onload = () => {
                  if (!text.startsWith("data:image")) {
                    URL.revokeObjectURL(text);
                  }
                };
              } else {
                chrome.runtime.sendMessage({
                  action: "invalidLinkFormat",
                  error: "Upload an image from your device.",
                });
              }
            });
          }
        }
      }
    } else {
      handleFiles(dt.files);
    }
  }

  function handleFiles(files) {
    [...files].forEach((file) => {
      if (isImageFile(file)) {
        processFile(file);
        // для PDF:
        //} else if (file.type === 'application/pdf') {
        // uploadPdf(file);
      } else {
        const url = URL.createObjectURL(file);
        changeViewToDisplayPreview();
        preloader.style.display = "block";
        previewImg.src = url;

        chrome.runtime.sendMessage({
          action: "upload_image_url",
          imageUrl: url,
        });

        previewImg.onload = () => {
          URL.revokeObjectURL(url);
        };
      }
    });
  }

  function processFile(file, url = null) {
    let reader = new FileReader();
    reader.onload = function (e) {
      if (reader.readyState === FileReader.DONE) {
        const result = reader.result;
        if (isImageFile(file)) {
          //|| file.type === 'application/pdf'
          changeViewToDisplayPreview();
          preloader.style.display = "block";
          previewImg.src = result;
          const messageData = { action: "upload_image", imageBase64: result };
          if (url) {
            messageData.imageUrl = url;
          }
          chrome.runtime.sendMessage(messageData);
        }
      }
    };
    reader.readAsDataURL(file);
  }

  function changeViewToDisplayPreview() {
    uploadInfo.style.display = "none";
    languageSelectWrapper.style.display = "none";
    previewImg.style.display = "block";
    backToMainBtn.disabled = true;
  }

  function resetTheInterface() {
    previewImg.src = "";
    previewImg.style.display = "none";
    resultText.textContent = "";
    result.style.display = "none";
    dropZone.style.display = "flex";
    uploadInfo.style.display = "flex";
    languageSelectWrapper.style.display = "flex";
  }

  isInterfaceImageToPromptReady = true;

  function isImageUrl(url) {
    return (
      url.match(/\.(jpeg|jpg|gif|png|webp)$/) != null ||
      url.startsWith("data:image")
    );
  }

  function copyToClipboard() {
    //----------------------------------------------
    const shadowHost = document.querySelector("#shadowHostITPrompt");
    const shadowRoot = shadowHost.shadowRoot;
    const shadowResultText = shadowRoot.querySelector("#shadowResult-text");
    const copyResultBtn = shadowRoot.querySelector("#shadowCopyResultBtn");
    const range = document.createRange();
    range.selectNode(shadowResultText);
    window.getSelection().removeAllRanges();
    window.getSelection().addRange(range);
    try {
      navigator.clipboard
        .writeText(window.getSelection().toString())
        .then(() => {
          copyResultBtn.textContent = "Done!";
          copyResultBtn.classList.add("done");

          setTimeout(() => {
            copyResultBtn.textContent = "Copy";
            copyResultBtn.classList.remove("done");
          }, 600);
        })
        .catch((err) => {
          console.error("Failed to copy: ", err);
        });

      window.getSelection().removeAllRanges();
    } catch (err) {
      console.error("Failed to copy: ", err);
    }
  }
  //------------------------------------
  function isImageFile(file) {
    return file.type.startsWith("image/");
  }
  
}
